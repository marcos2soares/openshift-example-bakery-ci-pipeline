<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR" sourcelanguage="en">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation type="unfinished">Java Script</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="unfinished">Ações</translation>
    </message>
    <message>
        <source>Document Will Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Will Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Did Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Will Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Did Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <source>Appearance Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show when printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show when displaying on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Arquivo</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="obsolete">Criar PDF</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Abrir</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation type="obsolete">Arquivos Recentes</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Ajuda</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation type="obsolete">Registro</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation type="obsolete">Verificar atualizações agora</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Ajuda...</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Salvar</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished">Arquivo</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="unfinished">Total de páginas:</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Cor</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished">Número da Página</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished">Aparência</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="unfinished">Opacidade</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished">Posição</translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished">Topo</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished">Centralizar</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished">Esquerda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished">Direita</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">milímetro</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="unfinished">Houve um erro ao imprimir o documento!</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <source>Bookmark Properties</source>
        <translation>Propriedades dos Marcador</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation>Simples</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Itálico</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation>Negrito e Itálico</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Ações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Adicionar uma Ação</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Alvo</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Mouse Acima</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Ir para Visualizar Página</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Abri/executar um Arquivo</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Abrir um link da rede</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Redefinir formulário</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Exibir/Ocultar campos</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Enviar um formulário</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Executar um JavaScript</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Número da Página</translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation>Definir a posição atual</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation>Você quer definir a posição atual?</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>The removed page(s) will never recovered, delete it anyway?</source>
        <translation type="obsolete">Deseja apagar estas páginas? O operação não poderá ser desfeita.</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation>Apagar Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>até:</translation>
    </message>
    <message>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>ALERTA: as páginas removidas não poderão ser recuperadas com a operação desfazer.</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>DialogFormFields</name>
    <message>
        <source>Button</source>
        <translation type="obsolete">Botão</translation>
    </message>
</context>
<context>
    <name>DialogNotes</name>
    <message>
        <source>Opacity</source>
        <translation type="vanished">Opacidade</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texto</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="obsolete">Aparência</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="obsolete">Cor</translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="obsolete">Autor:</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="obsolete">Assunto:</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="obsolete">Bloqueado</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="obsolete">Configurações</translation>
    </message>
</context>
<context>
    <name>DialogRotatePage</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cursor Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units and Markup Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> sq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <source>Page Number and Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Number Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>Start Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Página</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <source>Page Range Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Edit text</source>
        <translation type="vanished">Editar texto</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation type="vanished">Salvar Imagem do arquivo</translation>
    </message>
    <message>
        <source>Object Properties...</source>
        <translation type="vanished">Propriedades do Objeto...</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="obsolete">Excluir</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation type="obsolete">Salvar como</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Adicionar Anotação</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Realçar o Texto</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Riscar o Texto</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Sublinhar o Texto</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation>Adicionar Marcador</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="unfinished">Ir para Visualizar Página</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="unfinished">Executar um JavaScript</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation>Editar texto</translation>
    </message>
    <message>
        <source>Signature options</source>
        <translation>Opções de assinatura</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Abri Imagem</translation>
    </message>
    <message>
        <source>ERORR Load Image !</source>
        <translation>ERRO ao Carregar a Imagem!</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>Ajustar a Página</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation>Salvar Imagem para arquivo</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvar Como...</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>Imagens PNG (*.png);;Imagens BMP (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>Imagens PNG (*.png)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="vanished">Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Java script editor</source>
        <translation>Editor Java script</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation type="vanished">Ir para a página</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="vanished">automático</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="vanished">Topo</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="vanished">Esquerda</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="vanished">Número da Página</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation type="vanished">Zoom (%)</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="vanished">Abrir/executar um Arquivo</translation>
    </message>
    <message>
        <source>Edit a file</source>
        <translation type="vanished">Editar um arquivo</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <source>Select Fields</source>
        <translation>Selecionar Campos</translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation>Deselecionar Tudo</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <source>Method</source>
        <translation>Método</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="vanished">Abrir um link da web</translation>
    </message>
    <message>
        <source>Show/Hide Fields</source>
        <translation>Exibir/Ocultar Campos</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>Redefinir o Formulário</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation type="vanished">Introduza um arquivo:</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation type="vanished">Introduza um site da web:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Opções</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation type="vanished">Modo Zoom</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="vanished">Personalizar</translation>
    </message>
    <message>
        <source>Inherit Zoom</source>
        <translation type="vanished">Herdar Zoom</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="vanished">Ajustar a Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="vanished">Ajustar a Largura</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">AjusteV</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">AjusteR</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">AjusteB</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">AjusteBH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">AjusteBV</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Arquivo local</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Use anonymous</source>
        <translation>Usar anônimo</translation>
    </message>
    <message>
        <source>Need user name and password</source>
        <translation>Precisa de nome de usuário e senha</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Nome de usuário</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Todos os arquivos (*.*)</translation>
    </message>
    <message>
        <source>Select Field</source>
        <translation>Selecionar Campo</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um Arquivo</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation>Introduza um arquivo:</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation>Ir para uma página</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Número da Página</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation>Modo Zoom</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation>Zoom (%)</translation>
    </message>
    <message>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source>FitV</source>
        <translation type="vanished">AjusteV</translation>
    </message>
    <message>
        <source>FitR</source>
        <translation type="vanished">AjusteR</translation>
    </message>
    <message>
        <source>FitB</source>
        <translation type="vanished">AjusteB</translation>
    </message>
    <message>
        <source>FitBH</source>
        <translation type="vanished">AjusteBH</translation>
    </message>
    <message>
        <source>FitBV</source>
        <translation type="vanished">AjusteBV</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>automático</translation>
    </message>
    <message>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Abrir um link da web</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation>Digite um website:</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Todos os arquivos (*.*)</translation>
    </message>
    <message>
        <source>XYZ</source>
        <translation type="vanished">XYZ</translation>
    </message>
    <message>
        <source>Fit</source>
        <translation type="vanished">Ajuste</translation>
    </message>
    <message>
        <source>FitH</source>
        <translation type="vanished">AjusteH</translation>
    </message>
    <message>
        <source>Named Action</source>
        <translation>Ação Nomeada</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished">Personalizar</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <source>Extract pages as a single file</source>
        <translation>Extrair Páginas como um Arquivo Único</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Extract Pages</source>
        <translation>Extrair Páginas</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>Salvar Como PDF</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Não foi possível salvar para o arquivo:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>O arquivo pode ser somente leitura ou estar sendo usado por outra aplicação.</translation>
    </message>
    <message>
        <source>Export Pages</source>
        <translation>Exportar Páginas</translation>
    </message>
    <message>
        <source>Export Pages </source>
        <translation type="vanished">Exportar Páginas</translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation>Exportar Marcadores</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <source>Export to text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Name</source>
        <translation type="unfinished">Nome do Arquivo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Extract pages as a single file</source>
        <translation type="unfinished">Extrair Páginas como um Arquivo Único</translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished">Exportar</translation>
    </message>
    <message>
        <source>txt files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <source>Document Properties</source>
        <translation>Propriedades do Documento</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation>Informações do Documento</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Título</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Palavras-chave</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Criador</translation>
    </message>
    <message>
        <source>Producer</source>
        <translation>Produtor</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Segurança</translation>
    </message>
    <message>
        <source>Initial View</source>
        <translation>Visualização Inicial</translation>
    </message>
    <message>
        <source>Images</source>
        <translation type="vanished">Imagens</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Fontes</translation>
    </message>
    <message>
        <source>Fonts used in this document</source>
        <translation>Fontes usadas neste documento</translation>
    </message>
    <message>
        <source>Protection</source>
        <translation type="vanished">Proteção</translation>
    </message>
    <message>
        <source>User Password</source>
        <translation type="vanished">Senha do Usuário</translation>
    </message>
    <message>
        <source>Owner Password</source>
        <translation type="vanished">Senha do Proprietário</translation>
    </message>
    <message>
        <source>Password Encryption</source>
        <translation>Criptografar Senha</translation>
    </message>
    <message>
        <source>No Encryption</source>
        <translation>Descriptografado</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Imprimir o documento</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir uma versão de alta resolução do documento</translation>
    </message>
    <message>
        <source>Extract text and graphics</source>
        <translation type="vanished">Extrair texto e gráficos</translation>
    </message>
    <message>
        <source>Advanced extract text and graphics</source>
        <translation type="vanished">Extração Avançada de texto e gráficos</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Modificar documento</translation>
    </message>
    <message>
        <source>Modify annotations or form fields</source>
        <translation type="vanished">Modificar anotações ou campos de formulário</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Preencher os campos formulário e assinatura</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Gerenciar Páginas e Marcadores</translation>
    </message>
    <message>
        <source>Open to Page:</source>
        <translation>Abrir na Página:</translation>
    </message>
    <message>
        <source>of :</source>
        <translation>de:</translation>
    </message>
    <message>
        <source>PDF Information</source>
        <translation>Informações do PDF</translation>
    </message>
    <message>
        <source>Page Mode:</source>
        <translation type="vanished">Modo de Página:</translation>
    </message>
    <message>
        <source>Page Only</source>
        <translation>Página Única</translation>
    </message>
    <message>
        <source>Bookmarks Panel</source>
        <translation>Painel Marcadores</translation>
    </message>
    <message>
        <source>Pages Panel</source>
        <translation>Painel Páginas</translation>
    </message>
    <message>
        <source>Attachments Panel</source>
        <translation>Painel Anexos</translation>
    </message>
    <message>
        <source>Layers Panel</source>
        <translation>Painel Camadas</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="vanished">Tela Cheia</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Alterar</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>Extrair o conteúdo do documento</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>Conteúdo protegido por Direitos Autorais</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Run JavaScript on Document Open</source>
        <translation type="vanished">Executar JavaScript no Documento Aberto</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Adicionar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="vanished">Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Apagar</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>O documento é protegido. Por favor, digite a senha de permissão:</translation>
    </message>
    <message>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Senha incorreta. Por favor, digite a senha do proprietário.</translation>
    </message>
    <message>
        <source>User Interface Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide menu bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Window Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Windows Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center window on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display document title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in Full Screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout and Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Navigation Tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation type="unfinished">Página Simples</translation>
    </message>
    <message>
        <source>Single Page Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two-Up (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two-Up Continuous (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two-Up (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation type="unfinished">Zoom</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="unfinished">Tamanho Atual</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>25%</source>
        <translation type="unfinished">25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation type="unfinished">50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation type="unfinished">75%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation type="unfinished">100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation type="unfinished">125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation type="unfinished">150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation type="unfinished">200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation type="unfinished">300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation type="unfinished">400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation type="unfinished">600%</translation>
    </message>
</context>
<context>
    <name>FormDialogProp</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Aparência</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Opções</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="vanished">Ações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="vanished">Apagar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">Fechar</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Estilo</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="vanished">Cor</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="vanished">Adicionar</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation type="vanished">Bloqueado</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">Nome</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="vanished">Bordas e Cores</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation type="vanished">Dica da Ferramenta</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">Orientação</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="vanished">Estilo da linha</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="vanished">Espessura da Linha</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="vanished">Cor de Preenchimento</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="vanished">Cor da Borda</translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="vanished">Acima</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="vanished">Abaixo</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Propriedades do Documento</translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="obsolete">Texto</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Tamanho</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="obsolete">Inserir</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source>Header &amp; Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation type="unfinished">Margem superior</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="unfinished">Margem direita</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation type="unfinished">Margem inferior</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="unfinished">Margem esquerda</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished">Fonte</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Cor</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished">Família de Fontes</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Salvar</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">milímetro</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Insert Pages</source>
        <translation>Inserir Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Procurar</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Depois da última página</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Antes da primeira página</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>Total de páginas:</translation>
    </message>
    <message>
        <source>Error read: This PDF is protected.</source>
        <translation>Erro: este PDF é protegido.</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation>Antes da página</translation>
    </message>
    <message>
        <source>After page</source>
        <translation>Depois da página</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation>Importar Marcadores</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>O arquivo é protegido. Por favor, digite a senha para abrí-lo:</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <source>JavaScript Console</source>
        <translation>Console JavaScript</translation>
    </message>
    <message>
        <source>Run</source>
        <translation>Corre</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Claro</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation type="unfinished">Nome da Função</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Adicionar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <source>Java Script Editor</source>
        <translation>Editor Java Script</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Nome da Função</translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation>Java Script</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Formulários</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation>Cor de Realce</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation>Cor de Realce dos Campos</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation>Por favor, escolha o idioma da interface</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation>Verificar por Atualizações Automaticamente</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Semanalmente</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Mensalmente</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Nunca (OBS.: NÃO RECOMENDADO)</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source> ms</source>
        <translation>ms</translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation>Suavizar texto e imagens</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation>Tempo antes de um movimento ou de redimensionar: </translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation>Seleciona o item passando o mouse</translation>
    </message>
    <message>
        <source>Built-in</source>
        <translation>Construir</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>É necessário reiniciar o programa para que as alterações tenham efeito.</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="vanished">Barra de ferramentas</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Atualizações</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Árabe</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Búlgaro</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation>Catalão</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation>Chinês Simplificado</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation>Chinês Tradicional</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tcheco</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation>Dinamarquês</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Holandês</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Inglês</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation>Estoniano</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Finlandês</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Francês</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation>Galego</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Alemão</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Grego</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebraico</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Húngaro</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation>Irlandês</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japonês</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation>Letão</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation>Lituano</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation>Norueguês</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation>Novo Norueguês</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Polonês</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation>Português</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation>Português (do Brasil)</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Eslovaco</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation>Esloveno</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Espanhol</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Sueco</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Tailandês</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ucraniano</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation>Valenciana</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation>Salvando Documentos</translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation>Criar cópia de segurança do arquivo</translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Escolher destino para salvar os documentos</translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation>Última pasta usada</translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation>Pasta Documentos</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Procurar...</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>Fonte padrão</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Edição</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armênio</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <source>Restore last session when application start</source>
        <translation>Restaurar a última sessão quando iniciar a aplicação</translation>
    </message>
    <message>
        <source>Restore last view settings when reopening</source>
        <translation>Restaurar as últimas configurações definidas quando reabrir</translation>
    </message>
    <message>
        <source>Enable JavaScript</source>
        <translation>Ativar JavaScript</translation>
    </message>
    <message>
        <source> Always hide document message bar </source>
        <translation>Sempre ocultar a barra de mensagens do documento</translation>
    </message>
    <message>
        <source>Default Layout and Zoom</source>
        <translation>Formato e Zoom Padrões</translation>
    </message>
    <message>
        <source>Default page layout</source>
        <translation>Formato da página padrão</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>Página Simples</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>Páginas Opostas</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Tamanho Atual</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Ajustar Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Ajustar Largura</translation>
    </message>
    <message>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Bitmap Images</source>
        <translation>Imagens Bitmap</translation>
    </message>
    <message>
        <source>Vector Images</source>
        <translation>Imagens Vetoriais</translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation>Substituir Cores do Documento</translation>
    </message>
    <message>
        <source>Page Background</source>
        <translation>Fundo da Página</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Visualização</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source> Always show Object Inspector</source>
        <translation>Sempre exibir Inspecionar Objeto</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <source>Fusion Dark Style</source>
        <translation type="vanished">Estilo Fusion Dark</translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation>Selecionar diretório</translation>
    </message>
    <message>
        <source>Automatically change font when editing text</source>
        <translation>Alterar automaticamente a fonte quando editar o texto</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <source>System PPI</source>
        <translation>Sistema PPI</translation>
    </message>
    <message>
        <source>Icons in menus</source>
        <translation>Ícones em menus</translation>
    </message>
    <message>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Abrir documentos como novas abas na mesma janela (requer reinicialização)</translation>
    </message>
    <message>
        <source>Enable scroll wheel zooming</source>
        <translation>Zoom com o botão de rolagem do mouse</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Pop-up Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="unfinished">Opacidade</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation type="unfinished">Espessura da Linha</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentários</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation type="unfinished">Marca de Seleção</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="unfinished">Círculo</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished">Comentário</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished">Cruz</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">Ajuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation type="unfinished">Inserir Texto</translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="unfinished">Atalho</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation type="unfinished">Novo Parágrafo</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation type="unfinished">Nota de Texto</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation type="unfinished">Parágrafo</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation type="unfinished">Seta a Direita</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation type="unfinished">Ponteiro a Direita</translation>
    </message>
    <message>
        <source>Star</source>
        <translation type="unfinished">Estrela</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation type="unfinished">Seta para cima</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation type="unfinished">Seta para baixo</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation type="unfinished">Gráfico</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation type="unfinished">Clipe de Papel</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Anexos</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation type="unfinished">Rótulo</translation>
    </message>
    <message>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show errors and  messages in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="unfinished">Link</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation type="unfinished">Campo de texto</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation type="unfinished">Caixa de seleção</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation type="unfinished">Botão rádio</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation type="unfinished">Caixa de combinação</translation>
    </message>
    <message>
        <source>List box</source>
        <translation type="unfinished">Caixa de listagem</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="unfinished">Botão</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation type="unfinished">Assinatura</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation type="unfinished">Bordas e Cores</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation type="unfinished">Fino</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished">Médio</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation type="unfinished">Espesso</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation type="unfinished">Cor da Borda</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation type="unfinished">Cor de Preenchimento</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished">Sólido</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="unfinished">Pontilhado</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation type="unfinished">Chanfrado</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation type="unfinished">Inserir</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished">Sublinhado</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation type="unfinished">Espessura da Linha</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation type="unfinished">Automático</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished">Fonte</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation type="unfinished">Realçado</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="unfinished">Inverter</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation type="unfinished">Contorno</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished">Inserir</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished">Estilo</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="unfinished">Marcar</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation type="unfinished">Diamante</translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished">Quadrado</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">milímetro</translation>
    </message>
    <message>
        <source>Width between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Height between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subdivision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plastique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CleanLooks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motif</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Application Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use default program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>evolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>kmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thunderbird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Secure connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STARTTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SMTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished">Senha</translation>
    </message>
    <message>
        <source>Default path to tesseract ocr data files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional tesseract ocr config file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
    <message>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable safe reading mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct internet connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual proxy configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SOCKS 5 Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User name</source>
        <translation type="unfinished">Nome de usuário</translation>
    </message>
</context>
<context>
    <name>MainOptionsDlg</name>
    <message>
        <source>System</source>
        <translation type="obsolete">Geral</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation type="obsolete">Formulários</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Portugues</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation type="obsolete">Destacar cor</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation type="obsolete">Realçar Campos Solicitados:</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation type="obsolete">Por favor escolha o idioma preferido:</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation type="obsolete">Verificar automaticamente se existem Atualizações:</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation type="obsolete">Semanalmente</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation type="obsolete">Mensalmente</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nunca</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Configurações</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Procurar...</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Estilo</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Delete Object</source>
        <translation type="vanished">Apagar Objeto</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Novo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvar Como...</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>Arquivos Recentes</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Selecionar Tudo</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>Primeira Página</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Página Anterior</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Página Posterior</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>Última Página</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Aumentar Zoom</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Diminuir Zoom</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Tamanho Atual</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>Barra de Ferramenta</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Barra de Estado</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Ferramentas</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>Ferramenta Mão</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>Registrar...</translation>
    </message>
    <message>
        <source>Check for Update</source>
        <translation>Verificar por Atualizações</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation>Exportar para</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Ampliar as Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Reduzir as Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Insert Page(s) from PDF</source>
        <translation type="vanished">Inserir Página(s) do PDF</translation>
    </message>
    <message>
        <source>Extract Page(s) to PDF</source>
        <translation type="vanished">Extrair Página(s) para PDF</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Realçar Campos</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="obsolete">Todas as páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation type="obsolete">Plano</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation type="obsolete">Negrito Itálico</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation type="vanished">Marcadores</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Realçar Texto</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Sublinhar Texto</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Riscar Texto</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="vanished">Anexos</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>Caixa de seleção</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>Botão rádio</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Botão</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>Caixa de listagem</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Caixa de combinação</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>Campo de texto</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Documento</translation>
    </message>
    <message>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Você gostaria de salvar as alterações de %s antes de fechar?</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Help...</source>
        <translation type="obsolete">Ajuda...</translation>
    </message>
    <message>
        <source>Cannot open file :
</source>
        <translation>Não foi possível abrir o arquivo:</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Your version already has the last update!</source>
        <translation>Sua versão já tem a última atualização!</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>Editar documento</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Comentários</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Anotação</translation>
    </message>
    <message>
        <source>Add Sticky Notes</source>
        <translation type="obsolete">Anotação</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>Houve um erro ao imprimir o documento!</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>Formato da página</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="vanished">Inserir páginas</translation>
    </message>
    <message>
        <source>Insert a Blank Page(s)</source>
        <translation type="vanished">Inserir páginas</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation type="vanished">Excluir páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="vanished">Páginas</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <source>Create a new blank PDF</source>
        <translation>Criar um novo PDF em branco</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Imprimir (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Imprimir o documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation>Enviar para Trás</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enviar para Trás&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Enviar para Trás o objeto selecionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Principal</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <source>Home page</source>
        <translation>Página Oficial do Produto</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Desfazer (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Desfazer a última ação&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Refazer (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Refazer a ação desfeita anteriormente.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cortar (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cortar os Objetos selecionados e colocá-los na Área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copiar (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copiar os Objetos selecionados e colocá-los na Área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation>Selecionar Texto</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Open failed</source>
        <translation>Falha ao abrir</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation>Esvaziar a lista de arquivos recentes</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation>Exportação completada</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>Falha ao salvar</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Não é possível salvar para o arquivo:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente leitura ou está sendo utilizado por outra aplicação.</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation>Todos os arquivos (*.pdf *.xps);;Arquivos PDF (*.pdf);;Arquivos XPS (*.xps)</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation type="obsolete">Propriedades do Documento</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>Conteúdo</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Localizar</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>Localizar Próximo</translation>
    </message>
    <message>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Nova Versão Está Disponível! 
Você quer Baixá-la Agora?</translation>
    </message>
    <message>
        <source>Close Without Saving</source>
        <translation>Fechar sem Salvar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation>Girar Páginas</translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation>Mover Páginas</translation>
    </message>
    <message>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Editar Texto</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation type="obsolete">Descrição</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Inspecionar Objeto</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="vanished">A versão não registrada inserirá uma marca d&apos;água</translation>
    </message>
    <message>
        <source>Align Objects</source>
        <translation>Alinhar Objetos</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Retângulo</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Visualizar Impressão</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Alinhar à Esquerda</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Alinhar à Direita</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>Alinhar Acima</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>Alinhar a Baixo</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Assinatura</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>Ajustar à Página</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Ocorreu um erro durante a verificação da assinatura!</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Colar (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Colar da Área de transferência&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation>Editor Master PDF</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Formulários</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Início</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Fim</translation>
    </message>
    <message>
        <source>Reset Forms</source>
        <translation>Redefinir Formulários</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Ajustar Página</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Ajustar Largura</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>Páginas Opostas</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>Apagar Páginas</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation>Editar Formulários</translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation>Trazer para Frente</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Trazer para Frente&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Trazer para Frente o objeto selecionado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation>Extrair Páginas...</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation>Inserir Páginas...</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation>Lápis</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>Arquivos PDF (*.pdf)</translation>
    </message>
    <message>
        <source>Open a PDF file</source>
        <translation>Abrir um arquivo PDF</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>Pág. para Cima</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>Pág. para Baixo</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>Salvar em XPS é incompatível. Escolha o nome de arquivo PDF para salvar.</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation>Abrir Inspecionar Objeto</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation>Cortar Páginas</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation>Anterior/Próximo</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation>Ferramentas de Edição</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation>Página:</translation>
    </message>
    <message>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Inserir Páginas em Branco</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation>Ctrl+Shift++</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation>Ctrl+Shift+-</translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Girar 90 graus sentido anti-horário</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>Arquivos FDF (*.fdf)</translation>
    </message>
    <message>
        <source>Export Form Data...</source>
        <translation>Exportar Dados do Formulário...</translation>
    </message>
    <message>
        <source>Import Form Data...</source>
        <translation>Importar Dados do Formulário...</translation>
    </message>
    <message>
        <source>Export Comments Data...</source>
        <translation>Exportar Comentários...</translation>
    </message>
    <message>
        <source>Import Comments Data...</source>
        <translation>Importar Comentários...</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt; &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Abrir Arquivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Abrir um arquivo PDF ou XPS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Select text for copying and pasting</source>
        <translation>Selecionar texto para copiar e colar</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; 
p, li { white-space: pre-wrap; }
 &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Salvar (Ctrl+S)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Salvar o documento&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save the document</source>
        <translation>Salvar o documento</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
 p, li { white-space: pre-wrap; } 
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Sans Serif&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Salvar como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Salvar o documento com um novo nome&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save the document with a new name</source>
        <translation>Salvar o documento com um novo nome</translation>
    </message>
    <message>
        <source>Print the document</source>
        <translation>Imprimir o documento</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Documento (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona e edita texto, imagens, anotações, campos de formulário...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Selecionar e editar texto, imagens, anotações, campos de formulário...</translation>
    </message>
    <message>
        <source>Select text for editing</source>
        <translation>Seleciona o texto para edição</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
 &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
 p, li { white-space: pre-wrap; }
 &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Ubuntu&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
 &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;Apagar Objetos (Del)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8pt;&quot;&gt;Apaga os objetos selecionados&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Delete the currently selected object(s)</source>
        <translation>Apagar o(s) objeto(s) selecionado(s)</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Novo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Criar um novo PDF em branco&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Cortar os Objetos selecionados e colocá-los na Área de transferência</translation>
    </message>
    <message>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Copiar os Objetos selecionados e colocá-los na Área de transferência</translation>
    </message>
    <message>
        <source>Paste from the Clipboard</source>
        <translation>Colar da Área de transferência</translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation>Desfaz a última ação</translation>
    </message>
    <message>
        <source>Redo the previously undone action.</source>
        <translation>Refaz a ação desfeita anteriormente.</translation>
    </message>
    <message>
        <source>Send to Back selected object.</source>
        <translation>Envia para Trás o objeto selecionado.</translation>
    </message>
    <message>
        <source>Bring to Front selected object.</source>
        <translation>Traz para Frente o objeto selecionado.</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Propriedades (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Abrir a janela com as propriedades do documento&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Open window with document properties</source>
        <translation>Abrir a janela com as propriedades do documento</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Anotação&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Clique na página para adicionar uma nota nessa posição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Click the page to add a note at that position</source>
        <translation>Clique na página para adicionar uma nota nessa posição</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Inserir novo texto à página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new text to current page</source>
        <translation>Insere novo texto a página atual</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Imagem (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insira nova imagem para a página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new image to current page</source>
        <translation>Insire nova imagem a página atual</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;MS Shell Dlg 2&amp;apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Inserir Link (Ctrl+L)&lt;/span&gt;
&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insere novo link para a página atual&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new link to current page</source>
        <translation>Inserir novo link para a página atual</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Selecionar Texto (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona texto para copiar e colar&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>Salvar Otimizado como...</translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Chacters</source>
        <translation>Caracteres</translation>
    </message>
    <message>
        <source>Font type</source>
        <translation>Tipo de fonte</translation>
    </message>
    <message>
        <source>Font Embedded</source>
        <translation>Fonte Incorporada</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Filtro</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>Sombreamento</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Objetos</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Selecionado</translation>
    </message>
    <message>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <source>Can&apos;t find :</source>
        <translation>Não foi possível encontrar:</translation>
    </message>
    <message>
        <source>Font Not Embedded</source>
        <translation>Fonte Não Incorporada</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Formulário (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona formulário e anotações para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Editar Texto (Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Seleciona o texto para edição&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ferramenta mão (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use a ferramenta mão para mover as páginas, links abertos e selecionar texto.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation type="unfinished">Substituir Cores do Documento</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">Visualizar Impressão</translation>
    </message>
    <message>
        <source>Paste to Multiple Pages</source>
        <translation type="unfinished">Colar ...</translation>
    </message>
    <message>
        <source>Ctrl+Shift+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JavaScript Console</source>
        <translation>Console JavaScript</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>Ctrl+Shift+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F9</source>
        <translation type="unfinished">F9</translation>
    </message>
    <message>
        <source>Show Cover Page During Facing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="unfinished">Tela Cheia</translation>
    </message>
    <message>
        <source>F11</source>
        <translation type="unfinished">F11</translation>
    </message>
    <message>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Snap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+Shift+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Perimeter Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Area Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new document from scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Abrir Arquivo (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir um arquivo PDF ou XPS&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salvar o documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Salvar como PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Salvar o documento com um novo nome&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Apagar Objetos (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Apaga os objetos selecionados&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Novo (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Criar um novo PDF em branco&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Texto (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Inserir novo texto à página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Imagem (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insira nova imagem para a página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Inserir Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insere novo link para a página atual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Propriedades (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Abrir a janela com as propriedades do documento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <source>Recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <source>Not Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <source>Move Pages</source>
        <translation>Mover Páginas</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Página de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>até:</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation>Destino</translation>
    </message>
    <message>
        <source>To:</source>
        <translation>Para:</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Primeira</translation>
    </message>
    <message>
        <source>Last</source>
        <translation>Última</translation>
    </message>
</context>
<context>
    <name>MovePagesDlg</name>
    <message>
        <source>Page Range</source>
        <translation type="obsolete">Select Page Range</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="obsolete">Página atual</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="obsolete">até:</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="obsolete">Páginas Selecionadas</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <source>Page Size</source>
        <translation>Tamanho da Página</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation>Personalizar o tamanho da página</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>Tamanho do Conteúdo</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Margem esquerda</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Margem superior</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Margem direita</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Margem inferior</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>Antes da página atual</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>Depois da página atual</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Após a última página</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Antes da primeira página</translation>
    </message>
    <message>
        <source>Number of pages</source>
        <translation>Número de páginas</translation>
    </message>
    <message>
        <source>Page(s)</source>
        <translation>Página(s)</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Criar</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation>Carta</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation>Tablóide</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Confirmação</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation>Executivo</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation>Folha de papel</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>In-quarto</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Nota</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <source>points</source>
        <translation>pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation>polegada</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation>milímetro</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source> in</source>
        <translation>em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <source>OCR Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished">Selecionado</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searchable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished">Família de Fontes</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished">automático</translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
    <message>
        <source>Are you sure you want to stop document recognition?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <source>No Properties
There is no object selections.</source>
        <translation>Sem Propriedades. Não há objetos selecionados.</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>Propriedade</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Topo</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>Família de Fontes</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>Cor de Preenchimento</translation>
    </message>
    <message>
        <source>Stroke Color</source>
        <translation>Cor do Contorno</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <source>Form Field</source>
        <translation>Campo de Formulário</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Família de fontes&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a família de fontes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Ir para Visualizar Página</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Abrir/executar um Arquivo</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Abrir um link da web</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Redefinir formulário</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Exibir/Ocultar campos</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Enviar um formulário</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Executar um JavaScript</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Adicionar uma Ação</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Alvo</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Mouse Acima</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation>Mouse Abaixo</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation>Mouse Enter</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation>Mouse Sair</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation>Focar</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation>Desfocar</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Ações</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Up Label</source>
        <translation>Acima do Rótulo</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <source>Push</source>
        <translation>Empurrar</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>Inverter</translation>
    </message>
    <message>
        <source>Down Label</source>
        <translation>A baixo do Rótulo</translation>
    </message>
    <message>
        <source>RollOver Label</source>
        <translation>Em torno do Rótulo</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Item</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation>Exportar Valor</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Acima</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Abaixo</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation>Classificar Itens</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation>Confiar imediatamente no valor selecionado</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation>Seleção múltipla</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation>Permitir que o usuário digite o texto personalizado</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation>Rolar</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation>Verificar ortografia</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation>Limite de</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>caracteres</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation>Dividir em</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation>Permitir formatação Rich Text</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation>Multi-linha</translation>
    </message>
    <message>
        <source>cells</source>
        <translation>células</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centralizar</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation>Valor Padrão</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Alinhamento</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Marcar</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation>Cruz</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>Diamante</translation>
    </message>
    <message>
        <source>Square</source>
        <translation>Quadrado</translation>
    </message>
    <message>
        <source>Star</source>
        <translation>Estrela</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation>Marcado por Padrão</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>Cor da Borda</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>Estilo da Linha</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>Sólido</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>Pontilhado</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>Sublinhado</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>Realçado</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt; &lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt; p, li { white-space: pre-wrap; } &lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&amp;apos;Sans Serif&amp;apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Assinatura.&lt;/span&gt;&lt;/p&gt; &lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Nenhuma opção disponível&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <source>Format category</source>
        <translation>Categoria do formato</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Número</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Percentagem</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Horário</translation>
    </message>
    <message>
        <source>Special</source>
        <translation>Especial</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Personalizar</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <source>Currency Symbol</source>
        <translation>Símbolo Monetário</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dólar ($)</translation>
    </message>
    <message>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <source>Pound (£)</source>
        <translation>Libra (£)</translation>
    </message>
    <message>
        <source>Yen (¥)</source>
        <translation>Iene (¥)</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation>Rublo (Руб)</translation>
    </message>
    <message>
        <source>Show parentheses</source>
        <translation>Exibir parênteses</translation>
    </message>
    <message>
        <source>Decimal Places</source>
        <translation>Casas Decimais</translation>
    </message>
    <message>
        <source>Separation Style</source>
        <translation>Estilo da Separação</translation>
    </message>
    <message>
        <source>Use red text</source>
        <translation>Use o texto vermelho</translation>
    </message>
    <message>
        <source>Date Options</source>
        <translation>Opções de Data</translation>
    </message>
    <message>
        <source>Time Options</source>
        <translation>Opções de Horário</translation>
    </message>
    <message>
        <source>Special Options</source>
        <translation>Opções Especiais</translation>
    </message>
    <message>
        <source>Format Script</source>
        <translation>Formato Script</translation>
    </message>
    <message>
        <source>KeyStroke Script</source>
        <translation>KeyStroke Script</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation>Validar</translation>
    </message>
    <message>
        <source>Validation Script</source>
        <translation>Script de Validação</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation>Calcular</translation>
    </message>
    <message>
        <source>Calculation Script</source>
        <translation>Script de Cálculo</translation>
    </message>
    <message>
        <source>Fill text</source>
        <translation>Preenchimento do texto</translation>
    </message>
    <message>
        <source>Stroke Text</source>
        <translation>Contorno do Texto</translation>
    </message>
    <message>
        <source>Fill and Stroke</source>
        <translation>Preenchimento e Contorno</translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation>Invisível</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>Espessura da Linha</translation>
    </message>
    <message>
        <source>Character spacing</source>
        <translation>Espaçamento entre caracteres</translation>
    </message>
    <message>
        <source>Word spacing</source>
        <translation>Espaçamento entre palavras</translation>
    </message>
    <message>
        <source>F</source>
        <translation></translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>Coordinates</source>
        <translation>Coordenadas</translation>
    </message>
    <message>
        <source>Absolute</source>
        <translation>Absoluta</translation>
    </message>
    <message>
        <source>Relative</source>
        <translation>Relativa</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geométria</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <source>Matrix</source>
        <translation>Matriz</translation>
    </message>
    <message>
        <source>Cliping Path</source>
        <translation>Cliping Path</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Preenchimento</translation>
    </message>
    <message>
        <source>Stroke</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>Bordas e Cores</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Fino</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Médio</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation>Espesso</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation>Chanfrado</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation>Dicas da Ferramenta</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation>0 Graus</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation>90 Graus</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation>180 Graus</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation>270 Graus</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation>Somente Leitura</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Visível</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <source>Visible but doesn&apos;t print</source>
        <translation>Visível, mas não imprimir</translation>
    </message>
    <message>
        <source>Hidden but printable</source>
        <translation>Ocultar, mas imprimir</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Requerido</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation>Bloqueado</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor da Fonte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a cor de preenchimento&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cor do Contorno da Fonte&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Alterar a cor do contorno&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>Sombreamento</translation>
    </message>
    <message>
        <source>Image Form</source>
        <translation>Formato da Imagem</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>Maintain aspect ratio</source>
        <translation>Manter proporção</translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation>CEP</translation>
    </message>
    <message>
        <source>Zip Code+4</source>
        <translation>Zip Code+4</translation>
    </message>
    <message>
        <source>Phone Number</source>
        <translation>Número de Telefone</translation>
    </message>
    <message>
        <source>Social Security Number</source>
        <translation>Número da Segurança Social</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation>Marca de Seleção</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Comentário</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation>Inserir Texto</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Atalho</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation>Novo Parágrafo</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation>Nota de Texto</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>Parágrafo</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation>Seta a Direita</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation>Ponteiro a Direita</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation>Seta para cima</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation>Seta para baixo</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation>Gráfico</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation>Clipe de Papel</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Anexos</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation>Altezza della linea</translation>
    </message>
    <message>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selection change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Execute this script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">milímetro</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <source>Page Layout</source>
        <translation>Formato da Página</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>Tamanho do Conteúdo</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Margem esquerda</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Margem superior</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Margem direita</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Margem inferior</translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation>Tamanho da Página</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>até:</translation>
    </message>
    <message>
        <source> px</source>
        <translation type="vanished">px</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation>pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation>polegadas</translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation>milímetro</translation>
    </message>
    <message>
        <source> in</source>
        <translation>em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>Páginas ímpares</translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <source>Page Properties</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Tab Order</source>
        <translation>Ordem de Tabulação</translation>
    </message>
    <message>
        <source>Use Row Order</source>
        <translation>Usar ordenação por Linhas</translation>
    </message>
    <message>
        <source>Use Column Order</source>
        <translation>Usar ordenação por Coluna</translation>
    </message>
    <message>
        <source>Use Document Structure</source>
        <translation>Usar Estrutura do Documento</translation>
    </message>
    <message>
        <source>Unspecified</source>
        <translation>Não especificado</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Ações</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Adicionar uma Ação</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Alvo</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="obsolete">Mouse Acima</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Ação</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Ir para Visualizar Página</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Abri/executar um Arquivo</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Abrir um link da web</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Redefinir formulário</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Exibir/Ocultar campos</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Enviar um formulário</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Executar um JavaScript</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>O arquivo é protegido. Por favor, insira a senha para abrí-lo</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation>Digitar Senha</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <source>Paste to multiple pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation type="unfinished">Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished">Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>All pages</source>
        <translation type="unfinished">Todas as Páginas</translation>
    </message>
    <message>
        <source>Except current one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Esta fonte não contém esses caracteres.
Tente escolher outra fonte.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>Print Preview</source>
        <translation>Visualizar Impressão</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Impressora</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation type="vanished">Suavizar Bordas</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centralizar</translation>
    </message>
    <message>
        <source>Print as Grayscale</source>
        <translation>Imprimir com escala de cinza</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation>Proporção da Tela</translation>
    </message>
    <message>
        <source>Ignore aspect ratio</source>
        <translation>Ignorar Proporção da Tela</translation>
    </message>
    <message>
        <source>Keep aspect ratio</source>
        <translation>Manter Proporção da Tela</translation>
    </message>
    <message>
        <source>Keep aspect ratio by expanding</source>
        <translation>Manter a proporção pela expansão</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Retrato</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas de</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>até:</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Número de cópias</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Agrupar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Página</translation>
    </message>
    <message>
        <source>of:</source>
        <translation>de:</translation>
    </message>
    <message>
        <source>of </source>
        <translation>de</translation>
    </message>
    <message>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation>900</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation type="unfinished">Tamanho Atual</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished">automático</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvar como...</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Page </source>
        <translation type="vanished">Página</translation>
    </message>
    <message>
        <source>Attachment Tab</source>
        <translation>Aba Anexos</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation type="unfinished">Anexos</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Página</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <source>Add Bookmark</source>
        <translation>Adicionar Marcador</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation>Apagar Marcador</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>Propriedades do Marcador</translation>
    </message>
    <message>
        <source>Set Destination</source>
        <translation>Definir Destino</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>A Área de transferência não contém quaisquer dados</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <source>Close All</source>
        <translation>Fechar Tudo</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Salvar como</translation>
    </message>
    <message>
        <source>Move to New Window</source>
        <translation>Mover uma guia para uma nova janela.</translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <source>Email delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHTMLEditor</name>
    <message>
        <source>File</source>
        <translation type="obsolete">Arquivo</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Editar</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Refazer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Colar</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
</context>
<context>
    <name>QHtmlFormEditor</name>
    <message>
        <source>Undo</source>
        <translation type="obsolete">Desfazer</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="obsolete">Refazer</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="obsolete">Copiar</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="obsolete">Colar</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Negrito</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Itálico</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="vanished">Conexão HTTPS requisitada, mas o suporte a SSL não compilado em</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation type="vanished">Erro desconhecido</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation type="vanished">Requisição abortada</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation type="vanished">Nenhum servidor configurado para se conectar a</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation type="vanished">Tamanho do conteúdo errado</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation type="vanished">O servidor fechou a conexão inesperadamente</translation>
    </message>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation type="vanished">Conexão recusada (ou excedeu o tempo limite)</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation type="vanished">Host %1 não encontrado</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation type="vanished">Requisição HTTP falhou</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation type="vanished">Cabeçalho de resposta HTTP inválido</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation type="vanished">Método de autenticação desconhecido</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation type="vanished">Autenticação de proxy requerida</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation type="vanished">Autenticação requerida</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation type="vanished">HTTP com partes do corpo inválidas</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation type="vanished">Erro ao escrever resposta ao dispositivo</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Zoom In</source>
        <translation type="unfinished">Aumentar Zoom</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="unfinished">Diminuir Zoom</translation>
    </message>
    <message>
        <source>Zoom to Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear Selections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>You are not allowed to use this function in the free version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished">A versão não registrada inserirá uma marca d&apos;água</translation>
    </message>
    <message>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Based on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>64 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation type="unfinished">Mouse Enter</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation type="unfinished">Mouse Sair</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation type="unfinished">Mouse Abaixo</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation type="unfinished">Mouse Acima</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation type="unfinished">Focar</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation type="unfinished">Desfocar</translation>
    </message>
    <message>
        <source>Page Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KeyStroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="unfinished">Formatar</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation type="unfinished">Validar</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation type="unfinished">Calcular</translation>
    </message>
    <message>
        <source>Close Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document Printed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation type="unfinished">Ir para Visualizar Página</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation type="unfinished">Exibir/Ocultar campos</translation>
    </message>
    <message>
        <source>Submit Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation type="unfinished">Redefinir o Formulário</translation>
    </message>
    <message>
        <source>Import Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation type="unfinished">Executar um JavaScript</translation>
    </message>
    <message>
        <source>Rendition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Goto 3D View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confidential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reviewed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Revised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SignHere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Witness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <source>Error!</source>
        <translation>Erro!</translation>
    </message>
    <message>
        <source>There was a problem with your form submission.</source>
        <translation>Houve um problema com o envio do formulário.</translation>
    </message>
    <message>
        <source>Your form was successfully submitted!</source>
        <translation>Seu formulário foi enviado com sucesso!</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="unfinished">1</translation>
    </message>
    <message>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished">Página</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Ampliar as Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Reduzir as Miniaturas de Páginas</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Anexos</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Inspecionar Objeto</translation>
    </message>
    <message>
        <source>This document contains interactive form fields</source>
        <translation>Este documento contém campos de formulário interativos</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Realçar Campos</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Este documento é protegido. Você não tem permissão para editá-lo</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Alterar</translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation>Houve um erro ao imprimir o documento</translation>
    </message>
    <message>
        <source>Insert a blank page </source>
        <translation type="obsolete">Inserir páginas</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation>Você quer abrir?</translation>
    </message>
    <message>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Você tem certeza que quer definir o destino do Marcador selecionado para o local atual?</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>sem título</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>Apagar Páginas</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Inserir Páginas em Branco</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation type="unfinished">Páginas</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished">Girar 90 graus no sentido horário</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished">Girar 90 graus sentido anti-horário</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation type="unfinished">Erro!</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <source>More...</source>
        <translation>Mais...</translation>
    </message>
    <message>
        <source>User color %1</source>
        <translation type="vanished">Usar cor %1</translation>
    </message>
    <message>
        <source>User Color 99</source>
        <translation>Usar Cor 99</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Preto</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Branco</translation>
    </message>
    <message>
        <source>Red</source>
        <translation>Vermelho</translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation>Vermelho escuro</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation>Verde escuro</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation>Azul escuro</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Ciano</translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation>Ciano escuro</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Magenta</translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation>Magenta escuro</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Amarelo</translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation>Amarelo escuro</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Cinza</translation>
    </message>
    <message>
        <source>Dark gray</source>
        <translation>Cinza escuro</translation>
    </message>
    <message>
        <source>Light gray</source>
        <translation>Cinza claro</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <source>Registration Info</source>
        <translation>Informação de Registo</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Assim que seu pedido for concluído,
você automaticamente
receberá o seu Código de Registro por e-mail.</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation>Comprar Online</translation>
    </message>
    <message>
        <source>Registration Code</source>
        <translation>Código de Registro</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Ativar</translation>
    </message>
    <message>
        <source>Offline Activation</source>
        <translation>Ativação Offline</translation>
    </message>
    <message>
        <source>Registered version</source>
        <translation>Versão registrada</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Se você quer registrar esta licença em outro PC 
clique no botão &quot;Desativar&quot;. 

Em seguida, registre-o onde você precisar.</translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation>Desativar</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <source>Activation Code</source>
        <translation>Código de Ativação</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Por favor, envie a Chave de Identificação e Código de Registro para: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Depois que você receber seu código, digite-o no campo  &amp;quot;Código de Ativação&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>Chave de Identificação</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Fechar</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <source>Rotate</source>
        <translation>Girar</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Páginas</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Exemplo: 1,6-8,12</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Página Atual</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation type="vanished">Páginas de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation type="vanished">até:</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Direção</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation>90 graus no sentido horário</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation>180 graus</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation>90 graus no sentido anti-horário</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation type="unfinished">Páginas pares e ímpares</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation type="unfinished">Páginas pares</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation type="unfinished">Páginas ímpares</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Formatar</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Nome do Arquivo</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Páginas de</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>até:</translation>
    </message>
    <message>
        <source>Export to Image</source>
        <translation>Exportar para Imagem</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Intervalo de Páginas</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Todas as Páginas</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>Qualidade do JPEG</translation>
    </message>
    <message>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <source>TIFF Compression</source>
        <translation>Compressão TIFF</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Salvar</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Não é possível salvar para o arquivo:</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
O arquivo pode ser somente leitura ou está sendo utilizado por outra aplicação.</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation>Salvar Como Imagem</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Todos os arquivos (*)</translation>
    </message>
    <message>
        <source>MultiPage</source>
        <translation>Várias Páginas</translation>
    </message>
    <message>
        <source>Save As TIFF Image</source>
        <translation>Salvar Como Imagem TIFF</translation>
    </message>
    <message>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Arquivos TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation>Suavizar Bordas</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>Remove unused elements</source>
        <translation>Remover elementos não usados</translation>
    </message>
    <message>
        <source>Flatten form fields</source>
        <translation>Nivelar campos de formulário</translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation>Imagens com Cor e Escala de Cinza</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>Compression</source>
        <translation>Compressão</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation>Sem perdas</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>Qualidade do JPEG</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation>Imagens em Preto e Branco</translation>
    </message>
    <message>
        <source>CCITT Group 4</source>
        <translation>CCITT Group 4</translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>Salvar Otimizado como...</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancelar</translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished">Posição</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation type="unfinished">Antes da página atual</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After current page</source>
        <translation type="unfinished">Depois da página atual</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation type="unfinished">Antes da primeira página</translation>
    </message>
    <message>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Looking for devices. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <source>Scan more pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scanning complete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Search</source>
        <translation>Pesquisar</translation>
    </message>
    <message>
        <source>0 result</source>
        <translation>0 resultado</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>Maiúsculas e minúsculas</translation>
    </message>
    <message>
        <source> result</source>
        <translation>resultado</translation>
    </message>
    <message>
        <source> results</source>
        <translation>resultados</translation>
    </message>
    <message>
        <source> result(s)</source>
        <translation>resultado(s)</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>Incluir Comentários</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Case Sensitive</source>
        <translation>Maiúsculas e minúsculas</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>Incluir Comentários</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Security PDF</source>
        <translation>Segurança do PDF</translation>
    </message>
    <message>
        <source>Required a password to open the document</source>
        <translation>Requer uma senha para abrir o documento</translation>
    </message>
    <message>
        <source>Document Open Password</source>
        <translation>Senha para Abrir o Documento</translation>
    </message>
    <message>
        <source>Password Confirm</source>
        <translation>Confirmar Senha</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>Permissões</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>Comentar</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Modificar o documento</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>Acesso para cópia do conteúdo</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Imprimir o documento</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>Extrair o conteúdo do documento</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Imprimir uma versão de alta resolução do documento</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Preencher os campos do formulário ou assinatura existentes</translation>
    </message>
    <message>
        <source>Permissions Password</source>
        <translation>Permissões da Senha</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Gerenciar Páginas e Marcadores</translation>
    </message>
    <message>
        <source>Document Open password does not match.</source>
        <translation>A senha para Abrir o documento não corresponde.</translation>
    </message>
    <message>
        <source>Document Permission password does not match.</source>
        <translation>A senha de Permissão do documento não corresponde.</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <source>Signature Properties</source>
        <translation>Propriedades da Assinatura</translation>
    </message>
    <message>
        <source>Signature is VALID</source>
        <translation>A assinatura é INVÁLIDA</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Detalhes</translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation>Assinado por:</translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation>Razão:</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Local:</translation>
    </message>
    <message>
        <source>Validation Summary</source>
        <translation>Resumo da Validade</translation>
    </message>
    <message>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Informações de Contato do Assinante:</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <source>Text For Signing</source>
        <translation>Texto Para Assinatura</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Local</translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Razão</translation>
    </message>
    <message>
        <source>Lock document after signing</source>
        <translation>Bloquear o documento após a assinatura</translation>
    </message>
    <message>
        <source>Signature Preview</source>
        <translation>Visualizar Assinatura</translation>
    </message>
    <message>
        <source>I have reviewed this document</source>
        <translation>Eu revisei este documento</translation>
    </message>
    <message>
        <source>I am approving this document</source>
        <translation>Eu aprovo este documento</translation>
    </message>
    <message>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Eu atesto a exatidão e integridade deste documento</translation>
    </message>
    <message>
        <source>I agree to specified parts of this document</source>
        <translation>Eu concordo com determinadas partes deste documento</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Procurar...</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Abrir Arquivo</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation>Arquivo p12 (*.p12)</translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation>É necessário uma senha para abrir o certificado:</translation>
    </message>
    <message>
        <source>Sign</source>
        <translation>Assinar</translation>
    </message>
    <message>
        <source>Show Image</source>
        <translation>Exibir Imagem</translation>
    </message>
    <message>
        <source>Stretch Image</source>
        <translation>Esticar Imagem</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Show Text</source>
        <translation>Exibir Texto</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Ocorreu um erro durante a verificação da assinatura!</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Abrir Imagem</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Arquivos de imagem (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>O documento foi alterado ou corrompido desde que as assinaturas foram aplicadas.</translation>
    </message>
    <message>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>O documento não foi alterado desde que as assinaturas foram aplicadas.</translation>
    </message>
    <message>
        <source>Signature is INVALID</source>
        <translation>A assinatura é INVÁLIDA</translation>
    </message>
    <message>
        <source>Signature validity is UNKNOWN</source>
        <translation>A validade da assinatura é DESCONHECIDA</translation>
    </message>
    <message>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>A identidade do assinante é desconhecida, porque ela não foi incluída em sua lista de identidades confiáveis e nenhum de seus certificados pai são identidades confiáveis.</translation>
    </message>
    <message>
        <source>Error during signature verification.</source>
        <translation>Erro durante a verificação da assinatura.</translation>
    </message>
    <message>
        <source>Details: The signature byte range is invalid</source>
        <translation>Detalhes: o intervalo de bytes da assinatura são inválidos</translation>
    </message>
    <message>
        <source>I am the author of this document</source>
        <translation>Eu sou o autor deste documento</translation>
    </message>
    <message>
        <source>This certificate is not trusted</source>
        <translation>Este certificado não é confiável</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>Procurar...</translation>
    </message>
    <message>
        <source>Sign As</source>
        <translation>Assinar como</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished">Personalizar</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Email</source>
        <translation type="unfinished">E-mail</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <source>Issuer</source>
        <translation>Emissor</translation>
    </message>
    <message>
        <source>Common Name (CN)</source>
        <translation>Nome Comum (CN)</translation>
    </message>
    <message>
        <source>Organization (O)</source>
        <translation>Organização (O)</translation>
    </message>
    <message>
        <source>Organizational Unit (OU)</source>
        <translation>Unidade Organizacional (OU)</translation>
    </message>
    <message>
        <source>Serial Number</source>
        <translation>Número de Série</translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation>Algoritmo</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Assunto</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <source>Validity</source>
        <translation>Validade</translation>
    </message>
    <message>
        <source>Not Before</source>
        <translation>Não Antes</translation>
    </message>
    <message>
        <source>Not After</source>
        <translation>Não Depois</translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <source>Add to Trusted Identities</source>
        <translation>Adicionar para Identidades Confiáveis</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>Dados</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished">Personalizar</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <source>Custom Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished">Adicionar</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stamps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <source>Edit Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <source>Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished">Configurações</translation>
    </message>
</context>
<context>
    <name>TextDialog</name>
    <message>
        <source>Font:</source>
        <translation type="obsolete">Nome da Fonte</translation>
    </message>
    <message>
        <source>Font size:</source>
        <translation type="obsolete">Tamanho da fonte</translation>
    </message>
    <message>
        <source>Font color:</source>
        <translation type="obsolete">Cor do texto</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished">Configurações</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">Nenhum</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Salvar</translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished">Texto</translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished">Arquivo</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation type="unfinished">Total de páginas:</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation type="unfinished">Número da Página</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished">Fonte</translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished">Cor</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished">Tamanho</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation type="unfinished">Família de Fontes</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished">Aparência</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation type="unfinished">Opacidade</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished">Posição</translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="unfinished">Topo</translation>
    </message>
    <message>
        <source>Center</source>
        <translation type="unfinished">Centralizar</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished">Esquerda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished">Direita</translation>
    </message>
    <message>
        <source>Units</source>
        <translation type="unfinished">Unidades</translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished">pontos</translation>
    </message>
    <message>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>millimeter</source>
        <translation type="unfinished">milímetro</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> in</source>
        <translation type="unfinished">em</translation>
    </message>
    <message>
        <source> mm</source>
        <translation type="unfinished">mm</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation type="unfinished">Abrir Arquivo</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation type="unfinished">Houve um erro ao imprimir o documento!</translation>
    </message>
    <message>
        <source>auto</source>
        <translation type="unfinished">automático</translation>
    </message>
</context>
</TS>
