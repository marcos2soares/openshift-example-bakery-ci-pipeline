<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="60"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="86"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="93"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="39"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="61"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="71"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="77"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="91"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="289"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="295"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="353"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="359"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="385"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="484"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="98"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="118"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="134"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="167"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="193"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="199"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="237"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="293"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="303"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="309"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="323"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="382"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="337"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="342"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="398"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="347"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="368"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="393"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="403"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="411"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="419"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="424"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="461"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="115"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="115"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="125"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="160"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="160"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="219"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="235"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="253"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="273"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="273"/>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="299"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="289"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="348"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="329"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="201"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="209"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="66"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="210"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="202"/>
        <source>Measurement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="208"/>
        <location filename="../../src/DistanceToolDlg.ui" line="228"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="248"/>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="20"/>
        <source>Cursor Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="26"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="33"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="98"/>
        <source>Units and Markup Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="104"/>
        <source>Scale Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="122"/>
        <location filename="../../src/DistanceToolDlg.ui" line="158"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="127"/>
        <location filename="../../src/DistanceToolDlg.ui" line="163"/>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="132"/>
        <location filename="../../src/DistanceToolDlg.ui" line="168"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="140"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="189"/>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.ui" line="261"/>
        <source>°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="41"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="45"/>
        <source>Perimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="52"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="55"/>
        <source> sq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="215"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="218"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DistanceToolDlg.cpp" line="222"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="43"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="45"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="42"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="56"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="79"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="21"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="22"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="23"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="24"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="31"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="32"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="33"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="34"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="35"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1474"/>
        <location filename="../../src/docpage/docpage.cpp" line="1515"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1483"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1493"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1505"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2346"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="100"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="101"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="102"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="103"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="104"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="105"/>
        <source>Edit text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="106"/>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="107"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="108"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="109"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="110"/>
        <source>Save Image to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="914"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="916"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="926"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1894"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1894"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1931"/>
        <source>ERORR Load Image !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="104"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="106"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="176"/>
        <source>Show/Hide Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="180"/>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="210"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="90"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="91"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="162"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="160"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="162"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="143"/>
        <source>Export Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="34"/>
        <location filename="../../src/ExportPageDialog.cpp" line="72"/>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="111"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="113"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="85"/>
        <source>Export to text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="10"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="87"/>
        <source>txt files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="117"/>
        <location filename="../../src/ExportTextDialog.cpp" line="144"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="117"/>
        <location filename="../../src/ExportTextDialog.cpp" line="144"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="197"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="184"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="249"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="210"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="262"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="136"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="156"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="171"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="223"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="236"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="308"/>
        <source>Initial View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="314"/>
        <source>User Interface Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="320"/>
        <source>Hide tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="327"/>
        <source>Hide menu bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="334"/>
        <source>Hide Window Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="357"/>
        <source>Windows Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="363"/>
        <source>Center window on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="370"/>
        <source>Display document title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="377"/>
        <source>Open in Full Screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="387"/>
        <source>Layout and Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="393"/>
        <source>Navigation Tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="442"/>
        <source>Page layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <location filename="../../src/FileSettings.ui" line="499"/>
        <location filename="../../src/FileSettings.cpp" line="219"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>Single Page Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>Two-Up (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>Two-Up (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="488"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="504"/>
        <location filename="../../src/FileSettings.cpp" line="224"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="509"/>
        <location filename="../../src/FileSettings.cpp" line="229"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="514"/>
        <location filename="../../src/FileSettings.cpp" line="234"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="519"/>
        <location filename="../../src/FileSettings.cpp" line="239"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="524"/>
        <location filename="../../src/FileSettings.cpp" line="244"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="529"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="534"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="539"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="544"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="401"/>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="406"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="411"/>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="421"/>
        <source>Attachments Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="416"/>
        <source>Layers Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="582"/>
        <source>Open to Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="596"/>
        <source>of :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="607"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="623"/>
        <source>Fonts used in this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="443"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="444"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="461"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="14"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="130"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="94"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="153"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="71"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="32"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="40"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="45"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="50"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="189"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="195"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="215"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="235"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="333"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="352"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="366"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="374"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="288"/>
        <source>Right Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="295"/>
        <source>Center Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="302"/>
        <source>Left Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="309"/>
        <source>Right Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="316"/>
        <source>Center Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="323"/>
        <source>Left Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="427"/>
        <source>Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="420"/>
        <source>Insert Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="410"/>
        <source>Page number and date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="263"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="263"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="273"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="308"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="308"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="421"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="441"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="461"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="145"/>
        <location filename="../../src/ImportPageDialog.cpp" line="192"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="146"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="147"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="185"/>
        <source>Error read: This PDF is protected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="60"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="45"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="52"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="59"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="866"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1677"/>
        <source>Smooth text and images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="882"/>
        <source>Time before a move or resize starts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="895"/>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="156"/>
        <source>Saving Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="196"/>
        <source>Create backup file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="182"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="169"/>
        <source>Last used folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="174"/>
        <source>Original documents folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="292"/>
        <source>Required field highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="272"/>
        <source>Highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="767"/>
        <source>Default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2511"/>
        <source>Built-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2497"/>
        <source>Please choose the interface language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="998"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1018"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1084"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1091"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1828"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2532"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1845"/>
        <source>Selected text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1897"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1902"/>
        <source>Fusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1907"/>
        <source>Plastique</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1912"/>
        <source>CleanLooks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1917"/>
        <source>Motif</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1922"/>
        <source>CDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1930"/>
        <source>Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1950"/>
        <source>Application Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1970"/>
        <source>Use default program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1989"/>
        <source>evolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1994"/>
        <source>kmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1999"/>
        <source>thunderbird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2007"/>
        <source>Use SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2030"/>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2131"/>
        <source>Email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2036"/>
        <source>Secure connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2044"/>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2049"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2054"/>
        <source>STARTTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2121"/>
        <source>SMTP server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2084"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2111"/>
        <source>SMTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2091"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2422"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2183"/>
        <source>Default path to tesseract ocr data files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2222"/>
        <source>Additional tesseract ocr config file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2284"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2304"/>
        <source>Direct internet connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2314"/>
        <source>Manual proxy configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2330"/>
        <source>HTTP Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2337"/>
        <source>SOCKS 5 Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2347"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2357"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2062"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2400"/>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2412"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2598"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2603"/>
        <source>Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2608"/>
        <source>Monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="2584"/>
        <source>Check for Updates Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="189"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2199"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2238"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="531"/>
        <location filename="../../src/mainoptionsdialog.ui" line="828"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1051"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1259"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1398"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="502"/>
        <location filename="../../src/mainoptionsdialog.ui" line="779"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="17"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="206"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="218"/>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="225"/>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1111"/>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="328"/>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1548"/>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1554"/>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1572"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1649"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1654"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1659"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1561"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="77"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="82"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="102"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="107"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="112"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="235"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="255"/>
        <source>Enable scroll wheel zooming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="336"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="341"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="346"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="351"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="356"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="361"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="366"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="371"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="405"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="412"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="417"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="422"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="430"/>
        <location filename="../../src/mainoptionsdialog.ui" line="644"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="437"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="445"/>
        <location filename="../../src/mainoptionsdialog.ui" line="659"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="450"/>
        <location filename="../../src/mainoptionsdialog.ui" line="664"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="455"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="460"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="465"/>
        <location filename="../../src/mainoptionsdialog.ui" line="669"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="473"/>
        <location filename="../../src/mainoptionsdialog.ui" line="651"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="480"/>
        <location filename="../../src/mainoptionsdialog.ui" line="630"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="515"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="544"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="560"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="571"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="586"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="591"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="624"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="677"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="688"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="693"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="698"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="703"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="934"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="951"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="959"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="964"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="969"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="977"/>
        <source>Width between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="984"/>
        <source>Height between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="991"/>
        <source>Left offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1011"/>
        <source>Top offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1031"/>
        <source>Subdivision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1123"/>
        <source>Show errors and  messages in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1133"/>
        <source>Enable safe reading mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1499"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1504"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1577"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1582"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1587"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1592"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1597"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1602"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1607"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1612"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1617"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1622"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1627"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1632"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1637"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="490"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1683"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1784"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1690"/>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1697"/>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1726"/>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1772"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1791"/>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="87"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2735"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="97"/>
        <location filename="../../src/mainoptionsdialog.ui" line="399"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2747"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1667"/>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1878"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1720"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1736"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1188"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1208"/>
        <source>Pop-up Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1172"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1266"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1379"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1247"/>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1276"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1308"/>
        <location filename="../../src/mainoptionsdialog.ui" line="1476"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1484"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1489"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1494"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1424"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="1805"/>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="62"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2660"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2663"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="117"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2675"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="122"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2687"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="67"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2699"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="72"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2711"/>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="92"/>
        <location filename="../../src/mainoptionsdialog.ui" line="2723"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="361"/>
        <location filename="../../src/mainoptionsdialog.cpp" line="376"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="390"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="699"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="700"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="701"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="702"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="703"/>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="704"/>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="705"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="706"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="707"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="708"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="709"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="710"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="711"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="712"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="713"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="714"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="715"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="716"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="717"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="718"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="719"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="720"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="721"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="722"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="723"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="724"/>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="725"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="726"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="727"/>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="728"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="729"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="730"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="731"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="732"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="733"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="734"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="735"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="736"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="737"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="738"/>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="739"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="748"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="1724"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="1744"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="1764"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="576"/>
        <location filename="../../src/mainoptionsdialog.cpp" line="749"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="750"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="581"/>
        <location filename="../../src/mainoptionsdialog.cpp" line="751"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="752"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="753"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="754"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="755"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="756"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="757"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="758"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="759"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.ui" line="596"/>
        <location filename="../../src/mainoptionsdialog.cpp" line="760"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="761"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="762"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="763"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="764"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="765"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptionsdialog.cpp" line="766"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="157"/>
        <location filename="../../src/mainwindow.ui" line="1335"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="392"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="161"/>
        <source>Align Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="79"/>
        <location filename="../../src/mainwindow.ui" line="1327"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="418"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="187"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="115"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="271"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="113"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="235"/>
        <location filename="../../src/mainwindow.ui" line="1351"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="102"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="496"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="125"/>
        <location filename="../../src/mainwindow.ui" line="1343"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="464"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="53"/>
        <location filename="../../src/mainwindow.ui" line="1746"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="742"/>
        <location filename="../../src/mainwindow.cpp" line="2532"/>
        <source>Create a new blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="745"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="293"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="373"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="551"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="552"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="553"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="611"/>
        <source>Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="302"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="349"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="352"/>
        <source>Alt+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="386"/>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="401"/>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="442"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="471"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="497"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="515"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="524"/>
        <location filename="../../src/mainwindow.cpp" line="1935"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="530"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="533"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="542"/>
        <location filename="../../src/mainwindow.cpp" line="524"/>
        <location filename="../../src/mainwindow.cpp" line="4192"/>
        <location filename="../../src/mainwindow.cpp" line="4255"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="548"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="551"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="560"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="563"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="566"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="569"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="574"/>
        <location filename="../../src/mainwindow.ui" line="577"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="580"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="609"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="640"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="643"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="664"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="667"/>
        <source>Alt+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="676"/>
        <location filename="../../src/mainwindow.ui" line="1514"/>
        <location filename="../../src/mainwindow.ui" line="1560"/>
        <location filename="../../src/mainwindow.ui" line="1573"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="682"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="711"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form and annotations for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="736"/>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="756"/>
        <source>Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="764"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print Preview (Ctrl+Shift+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Preview the document before printing.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="770"/>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="785"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="803"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="821"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="854"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="869"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="887"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="905"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="914"/>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="917"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="920"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="985"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="990"/>
        <location filename="../../src/mainwindow.ui" line="993"/>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="996"/>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1001"/>
        <location filename="../../src/mainwindow.ui" line="1004"/>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1007"/>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1026"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1044"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1047"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1050"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1095"/>
        <location filename="../../src/mainwindow.ui" line="1596"/>
        <location filename="../../src/mainwindow.cpp" line="3496"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1101"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1104"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1113"/>
        <location filename="../../src/mainwindow.cpp" line="3505"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1119"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1122"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1185"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1197"/>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1212"/>
        <source>Check Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1224"/>
        <source>Radio Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1236"/>
        <source>Combo Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1248"/>
        <source>List Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1371"/>
        <location filename="../../src/mainwindow.ui" line="1374"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1379"/>
        <location filename="../../src/mainwindow.ui" line="1382"/>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1385"/>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1394"/>
        <location filename="../../src/mainwindow.ui" line="1397"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1406"/>
        <location filename="../../src/mainwindow.ui" line="1409"/>
        <location filename="../../src/mainwindow.ui" line="1412"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1417"/>
        <source>Export Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1422"/>
        <source>Import Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1427"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1432"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1437"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1440"/>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1451"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1464"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1469"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1477"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1482"/>
        <source>Paste to Multiple Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1485"/>
        <source>Ctrl+Shift+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1490"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1493"/>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1498"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1506"/>
        <location filename="../../src/mainwindow.ui" line="1552"/>
        <location filename="../../src/mainwindow.ui" line="1565"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1509"/>
        <source>Ctrl+Shift+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1525"/>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1528"/>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1536"/>
        <source>Show Cover Page During Facing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1544"/>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1547"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1555"/>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1568"/>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1578"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1583"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1588"/>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1591"/>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1599"/>
        <source>Shift+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1604"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1609"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1612"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1620"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1623"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1631"/>
        <source>Snap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1634"/>
        <source>Ctrl+Shift+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1642"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1650"/>
        <source>Perimeter Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1658"/>
        <source>Area Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1674"/>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1706"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1711"/>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1714"/>
        <location filename="../../src/mainwindow.ui" line="1717"/>
        <source>Create a new document from scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1722"/>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1725"/>
        <location filename="../../src/mainwindow.ui" line="1728"/>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1741"/>
        <source>Brush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="899"/>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="902"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="685"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1311"/>
        <source>Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="365"/>
        <location filename="../../src/mainwindow.ui" line="368"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="380"/>
        <location filename="../../src/mainwindow.ui" line="383"/>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="395"/>
        <location filename="../../src/mainwindow.ui" line="398"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="406"/>
        <location filename="../../src/mainwindow.ui" line="409"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="696"/>
        <source>Alt+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1215"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1200"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1227"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1251"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1239"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1319"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="355"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1272"/>
        <location filename="../../src/mainwindow.ui" line="1275"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="818"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="840"/>
        <location filename="../../src/mainwindow.ui" line="843"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1131"/>
        <location filename="../../src/mainwindow.ui" line="1134"/>
        <location filename="../../src/mainwindow.ui" line="1666"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1143"/>
        <location filename="../../src/mainwindow.ui" line="1146"/>
        <location filename="../../src/mainwindow.ui" line="1682"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1155"/>
        <location filename="../../src/mainwindow.ui" line="1158"/>
        <location filename="../../src/mainwindow.ui" line="1690"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="761"/>
        <location filename="../../src/mainwindow.ui" line="767"/>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="925"/>
        <location filename="../../src/mainwindow.ui" line="928"/>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <location filename="../../src/mainwindow.ui" line="936"/>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="941"/>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1012"/>
        <location filename="../../src/mainwindow.ui" line="1015"/>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="622"/>
        <location filename="../../src/mainwindow.ui" line="625"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="614"/>
        <location filename="../../src/mainwindow.ui" line="617"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="750"/>
        <location filename="../../src/mainwindow.ui" line="753"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="949"/>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1020"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1023"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1032"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1098"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1116"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1182"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1188"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1203"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1290"/>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1295"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1300"/>
        <source>Check for Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="863"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="866"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="872"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1167"/>
        <location filename="../../src/mainwindow.ui" line="1170"/>
        <location filename="../../src/mainwindow.ui" line="1698"/>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1260"/>
        <location filename="../../src/mainwindow.ui" line="1263"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="421"/>
        <location filename="../../src/mainwindow.ui" line="424"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="427"/>
        <source>Ctrl++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="451"/>
        <location filename="../../src/mainwindow.ui" line="454"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="457"/>
        <source>Ctrl+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="436"/>
        <location filename="../../src/mainwindow.ui" line="439"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="357"/>
        <location filename="../../src/mainwindow.ui" line="360"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1285"/>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="465"/>
        <location filename="../../src/mainwindow.ui" line="468"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="322"/>
        <location filename="../../src/mainwindow.ui" line="328"/>
        <source>Hand Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="658"/>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="968"/>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <source>Page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="881"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="884"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="890"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="779"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="137"/>
        <location filename="../../src/mainwindow.ui" line="1359"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="480"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="191"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="198"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="205"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="239"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="247"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="307"/>
        <location filename="../../src/mainwindow.ui" line="310"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="325"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="346"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="371"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="412"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="476"/>
        <location filename="../../src/mainwindow.ui" line="479"/>
        <source>Reset Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="491"/>
        <location filename="../../src/mainwindow.ui" line="494"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="509"/>
        <location filename="../../src/mainwindow.ui" line="512"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="527"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="545"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="591"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="603"/>
        <location filename="../../src/mainwindow.ui" line="606"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="661"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="679"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="690"/>
        <location filename="../../src/mainwindow.ui" line="693"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="708"/>
        <location filename="../../src/mainwindow.ui" line="714"/>
        <location filename="../../src/mainwindow.ui" line="1733"/>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="731"/>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="739"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="782"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="788"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="797"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="800"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="806"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="815"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="824"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="829"/>
        <location filename="../../src/mainwindow.ui" line="832"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="835"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="637"/>
        <source>Edit Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="646"/>
        <source>Alt+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1179"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1059"/>
        <location filename="../../src/mainwindow.ui" line="1062"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1041"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1071"/>
        <location filename="../../src/mainwindow.ui" line="1074"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1083"/>
        <location filename="../../src/mainwindow.ui" line="1086"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="343"/>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="717"/>
        <source>Alt+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1280"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="848"/>
        <location filename="../../src/mainwindow.ui" line="851"/>
        <location filename="../../src/mainwindow.ui" line="1459"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="453"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1448"/>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="979"/>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="960"/>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="331"/>
        <source>Alt+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1712"/>
        <source>Open failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1713"/>
        <source>Cannot open file :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="38"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="340"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="67"/>
        <source>Prev/Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="90"/>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="146"/>
        <source>Page :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="299"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="375"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="496"/>
        <location filename="../../src/mainwindow.cpp" line="4183"/>
        <location filename="../../src/mainwindow.cpp" line="4246"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="524"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../../src/mainwindow.cpp" line="3221"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="337"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="243"/>
        <location filename="../../src/mainwindow.cpp" line="308"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="453"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="659"/>
        <source>Export completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1051"/>
        <location filename="../../src/mainwindow.cpp" line="1067"/>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1929"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1936"/>
        <source>Close Without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1937"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2215"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2228"/>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2250"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2263"/>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2285"/>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2298"/>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2685"/>
        <location filename="../../src/mainwindow.cpp" line="2689"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3183"/>
        <source>Your installed version of Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3490"/>
        <source>Chacters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3491"/>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3493"/>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3495"/>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3501"/>
        <location filename="../../src/mainwindow.cpp" line="3584"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3502"/>
        <location filename="../../src/mainwindow.cpp" line="3585"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3503"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3509"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3513"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3525"/>
        <location filename="../../src/mainwindow.cpp" line="3581"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3525"/>
        <location filename="../../src/mainwindow.cpp" line="3594"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3598"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4192"/>
        <location filename="../../src/mainwindow.cpp" line="4213"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <location filename="../../src/mainwindow.cpp" line="4255"/>
        <location filename="../../src/mainwindow.cpp" line="4275"/>
        <location filename="../../src/mainwindow.cpp" line="4278"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2043"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="469"/>
        <location filename="../../src/mainwindow.cpp" line="538"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="54"/>
        <source>Ctrl+Shift++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="55"/>
        <source>Ctrl+Shift+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="470"/>
        <location filename="../../src/mainwindow.cpp" line="539"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="470"/>
        <location filename="../../src/mainwindow.cpp" line="539"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="30"/>
        <source>Your version already has the last update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="38"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="388"/>
        <location filename="../../src/mainwindow.cpp" line="391"/>
        <location filename="../../src/mainwindow.cpp" line="2684"/>
        <location filename="../../src/mainwindow.cpp" line="2688"/>
        <location filename="../../src/mainwindow.cpp" line="4213"/>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <location filename="../../src/mainwindow.cpp" line="4275"/>
        <location filename="../../src/mainwindow.cpp" line="4278"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="388"/>
        <location filename="../../src/mainwindow.cpp" line="391"/>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="725"/>
        <location filename="../../src/mainwindow.ui" line="728"/>
        <location filename="../../src/mainwindow.ui" line="1368"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="563"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="76"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="132"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="437"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="17"/>
        <source>Not Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="191"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="228"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="30"/>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="35"/>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="40"/>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="45"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="50"/>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="55"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="60"/>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="65"/>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="70"/>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="75"/>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="80"/>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="85"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="90"/>
        <source>Tabloid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="95"/>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="100"/>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="105"/>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="110"/>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="115"/>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="120"/>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="125"/>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="130"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="135"/>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="140"/>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="145"/>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="150"/>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="155"/>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="160"/>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="165"/>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="170"/>
        <source>Custom page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="215"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="220"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="264"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="272"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="277"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="282"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="293"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="305"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="345"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="365"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="388"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="394"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="411"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="418"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="404"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="428"/>
        <source>Number of pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="454"/>
        <source>Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="434"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="180"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="207"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="229"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="29"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="35"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="42"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="82"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="95"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="125"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="178"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="151"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="170"/>
        <source>Searchable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="180"/>
        <source>Editable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="200"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="220"/>
        <source>Manually edit all recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="56"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="262"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="144"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="57"/>
        <source>No Properties
There is no object selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="318"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2951"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3170"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1767"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="147"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="453"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="671"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="463"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2552"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="485"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1673"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1707"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1779"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1835"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2671"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="495"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="658"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="561"/>
        <source>Up Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="568"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="582"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1113"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1259"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1414"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="587"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="592"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="597"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1118"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="605"/>
        <source>Down Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="615"/>
        <source>RollOver Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="651"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="684"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="989"/>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="726"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="710"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="754"/>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Commit selected value immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="747"/>
        <source>Multiple selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="740"/>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="889"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="882"/>
        <source>Scrollable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="875"/>
        <source>Check spelling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="790"/>
        <source>Limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="804"/>
        <source>chars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="811"/>
        <source>Split into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="825"/>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="896"/>
        <source>Multi-line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="843"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2300"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="848"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="853"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="861"/>
        <source>Default Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="868"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="932"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2438"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="943"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="948"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="211"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="953"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="213"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="958"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="963"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="968"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="222"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1012"/>
        <source>Checked by Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1055"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2941"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1069"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2891"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1076"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2934"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1084"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2906"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1089"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2911"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1094"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2926"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1102"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1123"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1128"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1146"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1205"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2571"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1245"/>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1264"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1269"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1274"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1279"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1284"/>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1289"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1444"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="197"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="201"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1308"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1313"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1318"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1323"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1328"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1333"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1338"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1343"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1348"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1353"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1358"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1367"/>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1372"/>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1377"/>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1382"/>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1396"/>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1419"/>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1424"/>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1429"/>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1434"/>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1439"/>
        <source>Ruble (Руб)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1465"/>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1485"/>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1492"/>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1499"/>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1516"/>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1555"/>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1588"/>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1646"/>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1680"/>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1731"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1752"/>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1787"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1808"/>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1937"/>
        <source>Fill text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1942"/>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1947"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2731"/>
        <source>Fill and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1952"/>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1966"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2898"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1992"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2799"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3222"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2021"/>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2028"/>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2035"/>
        <source>Line height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2078"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2097"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2147"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2173"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2183"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2193"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2203"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2213"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2280"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2328"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2257"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2356"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2364"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2369"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2374"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2609"/>
        <source>Selection change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2637"/>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2644"/>
        <source>Execute this script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2721"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2739"/>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2916"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2921"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2976"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3040"/>
        <source>ToolTip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3056"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3064"/>
        <source>0 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3069"/>
        <source>90 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3074"/>
        <source>180 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3079"/>
        <source>270 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3100"/>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3115"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3120"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3125"/>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3130"/>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3138"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3148"/>
        <source>Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3177"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3232"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1872"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1901"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2963"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1917"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2701"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3252"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2307"/>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2315"/>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2320"/>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2397"/>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2419"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3005"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2457"/>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2476"/>
        <source>Cliping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2495"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2514"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2533"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2590"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2726"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2774"/>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2764"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2786"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2992"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3202"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2866"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2873"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2878"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2883"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1979"/>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2005"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2751"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2812"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3215"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="204"/>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="210"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="212"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="214"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="215"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="216"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="217"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="218"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="219"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="220"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="221"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="223"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="224"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="225"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="226"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="227"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="228"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1292"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1299"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1312"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1319"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1365"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1371"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1547"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3458"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1552"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3478"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1556"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3498"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1791"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1833"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1857"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1859"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1861"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1863"/>
        <source>Image Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2270"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2290"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1812"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3107"/>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3030"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1304"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1353"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2847"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="409"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="341"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="347"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="355"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="365"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="375"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="380"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="401"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="419"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="429"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="434"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="439"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="69"/>
        <location filename="../../src/PageLayoutDialog.ui" line="89"/>
        <location filename="../../src/PageLayoutDialog.ui" line="121"/>
        <location filename="../../src/PageLayoutDialog.ui" line="138"/>
        <location filename="../../src/PageLayoutDialog.ui" line="155"/>
        <location filename="../../src/PageLayoutDialog.ui" line="172"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="257"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="102"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="131"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="148"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="165"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="284"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="306"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="185"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="196"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="201"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="206"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="214"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="281"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="286"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="304"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="294"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="220"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="252"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="50"/>
        <source>Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="69"/>
        <source>Use Row Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="76"/>
        <source>Use Column Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="62"/>
        <source>Use Document Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="83"/>
        <source>Unspecified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="120"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="126"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="201"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="214"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="245"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="207"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="259"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="264"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="269"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="274"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="279"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="284"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="289"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="221"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="327"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="50"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="141"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="160"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="78"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="88"/>
        <source>Except current one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/plaintextedit.cpp" line="235"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="56"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="71"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="95"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="100"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="105"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="110"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="115"/>
        <source>900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="120"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="134"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="272"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="279"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="286"/>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="293"/>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="300"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="305"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="310"/>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="324"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="331"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="336"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="341"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="423"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="446"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="87"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="150"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="198"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="226"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="188"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="422"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="159"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="242"/>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="256"/>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="75"/>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="110"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="17"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="37"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="38"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="39"/>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="479"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="40"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="109"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="113"/>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="459"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="23"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="27"/>
        <source>Close All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="31"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="35"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="39"/>
        <source>Move to New Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="137"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="863"/>
        <location filename="../../src/document/qdoctab.cpp" line="886"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="9"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <location filename="../../src/scanner/linux/src/qimageviewer.cpp" line="96"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qimageviewer.cpp" line="100"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qimageviewer.cpp" line="104"/>
        <source>Zoom to Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qimageviewer.cpp" line="108"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/src/qimageviewer.cpp" line="112"/>
        <source>Clear Selections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="6"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="10"/>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="15"/>
        <source>Open with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="21"/>
        <location filename="../../src/app_config.cpp" line="26"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="33"/>
        <location filename="../../src/app_config.cpp" line="37"/>
        <location filename="../../src/app_config.cpp" line="41"/>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="21"/>
        <location filename="../../src/app_config.cpp" line="26"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <source>Based on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="21"/>
        <location filename="../../src/app_config.cpp" line="37"/>
        <source>32 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="26"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="33"/>
        <location filename="../../src/app_config.cpp" line="41"/>
        <source>64 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="48"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="53"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="58"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="63"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="68"/>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="73"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="78"/>
        <source>Confidential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="83"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="88"/>
        <source>Reviewed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="93"/>
        <source>Revised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="98"/>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="103"/>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="108"/>
        <source>Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="113"/>
        <source>Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="118"/>
        <source>Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="123"/>
        <source>Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="128"/>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="133"/>
        <source>Accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="138"/>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="143"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="148"/>
        <source>SignHere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="153"/>
        <source>Witness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="158"/>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="163"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="168"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="13"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="15"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="17"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="19"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="21"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="23"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Page Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Page Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Page Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Page Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>KeyStroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Close Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Save Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>Document Saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Document Printed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="68"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="70"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="72"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="74"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="76"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="78"/>
        <source>Thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <source>Movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Submit Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Import Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="100"/>
        <source>Rendition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Goto 3D View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="556"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="558"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="560"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="562"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="572"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="574"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="568"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="570"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="572"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="574"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2151"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2623"/>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2625"/>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="100"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="105"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="108"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="125"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="113"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="117"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="120"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="143"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="157"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="168"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="186"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="513"/>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="514"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="532"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="533"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1005"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1260"/>
        <location filename="../../src/docpage/qtabpage.cpp" line="1296"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1728"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="2597"/>
        <source>Do you want to open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3315"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3381"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="131"/>
        <source>More...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="318"/>
        <source>User Color 99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="332"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="333"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="345"/>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="347"/>
        <source>Dark gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="348"/>
        <source>Light gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="350"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="242"/>
        <source>Registration Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="262"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="170"/>
        <source>Registered version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="177"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="203"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="282"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="343"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="252"/>
        <source>Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="303"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="289"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="52"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="62"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="83"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="88"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="93"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="101"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="111"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="118"/>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="123"/>
        <source>180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="128"/>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="29"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="39"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="51"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="67"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="84"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="107"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <location filename="../../src/SaveImageDialog.ui" line="217"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="113"/>
        <source>BMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>PNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="158"/>
        <source>TIFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="127"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="197"/>
        <source>LZW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="202"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="207"/>
        <source>CCITT FAX 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>CCITT FAX 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="134"/>
        <source>TIFF Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="141"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="225"/>
        <source>MultiPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="235"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="241"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="267"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="331"/>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="293"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="76"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="76"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="430"/>
        <source>Save As TIFF Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="430"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="449"/>
        <source>Save As Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="449"/>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="39"/>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="49"/>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="78"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="233"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="123"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="266"/>
        <source>Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="143"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="286"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="148"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="156"/>
        <source>Lossless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="176"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="221"/>
        <source>Black and White Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="291"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="296"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="10"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="37"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="43"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="30"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="52"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="39"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="58"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="45"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="68"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="55"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="75"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="62"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="82"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="69"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="107"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="94"/>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="114"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="101"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="136"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="123"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="142"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="151"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="156"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="135"/>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="190"/>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="229"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="249"/>
        <source>Looking for devices. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="55"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="63"/>
        <source> result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="65"/>
        <source> result(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="67"/>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="76"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="77"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="78"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="71"/>
        <location filename="../../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="84"/>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="96"/>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="21"/>
        <source>Signature is VALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="364"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="417"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="447"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="371"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="454"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="357"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="376"/>
        <source>Show Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="405"/>
        <source>Stretch Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="398"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="348"/>
        <source>Show Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="244"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="224"/>
        <source>Sign As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="254"/>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="266"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="282"/>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="299"/>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="312"/>
        <source>Signature Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="40"/>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="41"/>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="42"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="43"/>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="18"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="19"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="20"/>
        <source>Signature is INVALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="22"/>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="23"/>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="24"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Error during signature verification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="26"/>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="27"/>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="355"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="440"/>
        <source>Digitally signed by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="361"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="444"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="398"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="398"/>
        <source>p12 Files (*.p12)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="383"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="218"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="295"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="167"/>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="99"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="22"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="39"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="61"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="71"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="77"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="107"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="114"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="124"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="348"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="354"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="435"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="551"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="557"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="588"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="131"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="151"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="157"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="177"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="184"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="200"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="233"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="256"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="262"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="280"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="300"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="356"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="366"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="372"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="386"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="445"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="400"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="405"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="461"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="410"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="431"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="456"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="466"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="474"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="482"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="487"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="492"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="524"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="157"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="157"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="167"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="203"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="203"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="276"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="292"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="310"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="332"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="332"/>
        <source>PDF Files (*.pdf *.PDF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="358"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
